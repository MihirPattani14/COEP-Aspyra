from flask import *
import image_save
from nocache import nocache
from werkzeug import secure_filename
import os
from flask.ext.mysql import MySQL
from flask.ext.compress import Compress

compress = Compress()

import generate_random,generate_hash,mail
from PIL import Image
mysql = MySQL()
app = Flask(__name__)
compress.init_app(app)
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = ''
app.config['MYSQL_DATABASE_DB'] = 'aspyra'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.secret_key = os.urandom(24)

mysql.init_app(app)

basedir = os.path.abspath(os.path.dirname(__file__))
user_session = {}
user_data = {}

@app.route('/')
@nocache
def main():
    global user_session
    user_session.clear()
    resp = Response("Foo bar baz")
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'

    return render_template('index.html')


@app.route('/deletesession',methods=['GET'])
def deletesession():
    global user_session
    if request.method == 'GET':
        user_session.pop('username',None)
        user_session.clear()
        return json.dumps({'yo':str(user_session)})

@app.route('/signIn',methods=['POST'])
@nocache
def signIn():
    global user_session
    _username = request.form['username']
    _password = request.form['password']
    connection = mysql.connect()
    cursor = connection.cursor()
    query = "select salt from secure_login where MIS = '" + _username+ "'"
    cursor.execute(query)
    data = cursor.fetchone()
    if data is None:
        return json.dumps({'status':'Username does not exist'})
    _password = _password + data[0]
    _password = generate_hash.hash(_password)
    query = "select * from secure_login where MIS = '" + _username + "' and password = '" + _password + "'"
    cursor.execute(query)
    data = cursor.fetchone()
    if data is not None:
        global user_data
        user_session['username'] = _username
        user_data['name']= str(data[1])
        user_data['number'] = str(data[2])
        user_data['mis'] = str(data[3])
        user_data['email'] = str(data[6])
        user_data['url'] = str(data[7])
        user_data['fg'] = str(data[8])
        user_data['id'] = str(data[0])
        return json.dumps({'status':'200'})#,
    else:
        return json.dumps({'status':'Incorrect Password'})


@app.route('/SignUp',methods=['POST'])
def SignUp():
    connection = mysql.connect()
    cursor = connection.cursor()
    _mis = request.form['mis']
    _fname = request.form['f_name']
    _passwd = request.form['passwd_reg']
    _email = request.form['email_reg']
    _phone = request.form['number_reg']
    _salt = generate_random.generate_random()
    _passwd = _passwd + _salt
    _passwd = generate_hash.hash(_passwd)
    query = "INSERT INTO secure_login (email,password,salt,name,number,MIS) VALUES ('" + _email + "','" + _passwd + "','" + _salt + "','" + _fname + "','" + _phone + "','" + _mis + "' )"
    cursor.execute(query)
    connection.commit()
    mail.sendmail(_email)
    return json.dumps({'html':query})
@app.route('/forgot_pass')
@nocache
def forgot_pass():
    return render_template('forgot.html')

@app.route('/forgot',methods=['POST'])
def forgot():
    _mis = request.form['mis']
    _email = request.form['username']
    connection = mysql.connect()
    cursor = connection.cursor()
    query = "select id from secure_login where MIS = '" + _mis+ "' and email = '" + _email + "'"
    cursor.execute(query)
    data = cursor.fetchone()
    if data is None:
        return json.dumps({'html':'404'})
    _salt = generate_random.generate_random()
    _pass = generate_random.generate_random()
    _passwd = _pass + _salt
    _passwd = generate_hash.hash(_passwd)
    query = "update secure_login set salt = '" + _salt + "' , password = '" + _passwd + "' , fg = '1' where MIS = '" + _mis + "' and email = '" + _email + "'"
    cursor.execute(query)
    connection.commit()
    mail.forgot(_email,_pass)
    return json.dumps({'r':query})

@app.route('/checkfg',methods=['POST'])
def checkfg():
    global user_data
    connection = mysql.connect()
    cursor = connection.cursor()
    query = "select fg from secure_login where id = '" + user_data['id']+ "'"
    cursor.execute(query)
    data = cursor.fetchone()
    if data[0] == '1':
        return json.dumps({'status':'forgot'})
    else:
        return json.dumps({'status':'nfg'})

@app.route('/photo',methods=['POST','GET'])
def photo():
    connection = mysql.connect()
    cursor = connection.cursor()
    files = request.files['input-file-preview']
    mis = str(request.form['mis'])
    os.makedirs(basedir+'/static/uploads/'+mis)
    if files :
        updir = os.path.join(basedir, 'static/uploads/'+mis)
        files.save(os.path.join(updir, mis+'.png'))
        image_save.save_image(os.path.join(updir, mis+'.png'),mis,updir)
        up = '../static/uploads/'+mis+'/'+mis
        query = "update secure_login set profile_url = '" + up + "' WHERE MIS = '" + mis + "'"
        cursor.execute(query)
        connection.commit()
        return json.dumps({'html':query})


@app.route('/checkusername',methods=['POST'])
def checkusername():
    _mis = request.form['mis']

    connection = mysql.connect()
    cursor = connection.cursor()
    query = "select id from secure_login where MIS = '" + _mis +"'"
    cursor.execute(query)
    connection.commit()
    data = cursor.fetchone()
    if data is None:
        return json.dumps({'status':'available'})
    else:
        return json.dumps({'status':'na'})

@app.route('/login')
@nocache
def login():
    global user_session
    resp = Response("Foo bar baz")
    resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    if 'username' in user_session:
        return render_template('/draft_1/index.html')
    return render_template('no_login.html')

@app.route('/check_login',methods=['GET'])
def check_login():
    global user_session
    if 'username' in user_session:
        return json.dumps({'status':'200' + str(user_session)})
    else:
        return json.dumps({'status':'500'})

@app.route('/change_pass')
@nocache
def change_pass():
    if 'username' in user_session:
        return render_template('change_pass.html')
    return render_template('no_login.html')


@app.route('/change_pass_db',methods=['POST'])
def change_pass_db():
    global user_data
    connection = mysql.connect()
    cursor = connection.cursor()
    _passwd = request.form['pass']
    _salt = generate_random.generate_random()
    _passwd = _passwd + _salt
    _passwd = generate_hash.hash(_passwd)
    query = "update secure_login set password = '" +_passwd+"' , salt = '" + _salt + "' , fg = '0' where id = '" + user_data['id'] +"'"
    cursor.execute(query)
    connection.commit()
    return json.dumps({'status':'200'})

@app.route('/logout')
def logout():
    global user_data,user_session
    user_data.clear()
    user_session.clear()
    return render_template('logout.html')

@app.route('/getuser_data',methods=['POST'])
def getuser_data():

    return json.dumps({'name':user_data['name'],'number':user_data['number'],'mis':user_data['mis'],'email':user_data['email'],'url':user_data['url'],'id':user_data['id']})

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000)