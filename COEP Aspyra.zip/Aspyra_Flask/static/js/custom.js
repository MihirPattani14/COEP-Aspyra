var c_mis = false;
var c_name = false;
var c_email  = false;
var c_pass = false;
var c_phone = false;
var c_mis_login = false;
var c_pass_login = false;
function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

function rem()
{
    var mis = document.getElementById('login-username').value;
    var pass = document.getElementById('login-password').value;
    var pass_enc = CryptoJS.AES.encrypt(pass, "shubham123").toString();
    var mis_enc = CryptoJS.AES.encrypt(mis, "shubham123").toString();
    localStorage.setItem('mis',mis);
    localStorage.setItem('pass',pass_enc);
}
function init()
{
    document.getElementById('btnSignUp').disabled = true;
    document.getElementById('btnSignIn').disabled = true;
    document.getElementById('username').value = "";
    document.getElementById('firstname').value = "";
    document.getElementById('login-username').value = "";
    document.getElementById('alert-1').style.display = "none";
    if(localStorage.getItem('mis') === null || localStorage.getItem('pass') === null)
        {
            document.getElementById('r').checked = false;
        }
    else
        {
            
            document.getElementById('login-username').value = localStorage.getItem('mis');
            document.getElementById('login-password').value = CryptoJS.AES.decrypt(localStorage.getItem('pass'),"shubham123").toString(CryptoJS.enc.Utf8);
                document.getElementById('btnSignIn').disabled = false;
                        document.getElementById('r').checked = true;


        }
    document.getElementById('passwd').value = "";
    document.getElementById('re-passwd').value = "";
    document.getElementById('email').value = "";
    document.getElementById('number').value = "";
}
function validate()
{
	if( c_email && c_mis && c_name && c_pass && c_phone)
        {
            document.getElementById('btnSignUp').disabled = false;
        }
    else
    document.getElementById('btnSignUp').disabled = true;

    if(c_mis_login && c_pass_login)
    document.getElementById('btnSignIn').disabled = false;
    else
    document.getElementById('btnSignIn').disabled = true;
   

}
function check_login_mis()
{
    var mis = document.getElementById('login-username').value;
    if(mis == "" || !/\S/.test(mis) )
        {
            c_mis_login = false;
            validate();
        }
    else
        {
            c_mis_login = true;
            validate();
        }
}

function check_login_pass()
{
    var pass = document.getElementById('login-password').value;
    if(pass == "" || !/\S/.test(mis) )
        {
            c_pass_login = false;
            validate();
        }
    else
        {
            c_pass_login = true;
            validate();
        }
}



function check_mis()
{
    
    var mis = document.getElementById('username').value;
    if(/^\d+$/.test(mis) && mis.length == 9) {
        c_mis = true;
        document.getElementById('mis').className = "input-group has-success";
            validate();

 //proceed with rest of code
}
    
    else
        {
            document.getElementById('mis').className = "input-group has-error";
            c_mis = false;
            validate();
        }
}

function check_name()
{
    var n = document.getElementById('firstname').value;
    if(!/\S/.test(n) || name == null)
    {
        document.getElementById('fname').className = "input-group has-error";
        c_name = false;
        validate();
    }
    else
    {
    document.getElementById('fname').className = "input-group has-success";
    c_name = true;
            validate();

    }

}

function check_pass()
{
    var pass = document.getElementById('passwd').value;
    var re_pass = document.getElementById('re-passwd').value;
    
    if(!/\S/.test(pass) || !/\S/.test(re_pass) || pass != re_pass || pass.length < 6 || re_pass.length < 6)
    {
        document.getElementById('repass').className =  "input-group has-error";
        document.getElementById('pass').className = "input-group has-error";
        c_pass = false;
        validate();

    }
    
    else
        {
        document.getElementById('repass').className =  "input-group has-success";
        document.getElementById('pass').className =  "input-group has-success";
        c_pass = true;
     validate();

        }
    
}

function check_email()
{
    var email = document.getElementById('email').value;
var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
if (filter.test(email))
{
    document.getElementById('mail').className =  "input-group has-success";
    c_email = true;
        validate();

}
    
else
    { 
        document.getElementById('mail').className = "input-group has-error";
        c_email = false;
        validate();

    }
}

function check_phone()
{
    var phone = document.getElementById('number').value;
    if(/^\d+$/.test(phone) && phone.length == 10 ){
            document.getElementById('num').className =  "input-group has-success";
            c_phone = true;
            validate();


    }
    
    else{
        document.getElementById('num').className =  "input-group has-error";
        c_phone = false;
        validate();
    }

}


function clearphoto()
{
    var oldInput = document.getElementById('ph');
    var newInput = document.createElement("input"); 
    newInput.type = "file"; 
    newInput.id = oldInput.id; 
    newInput.name = oldInput.name; 
    newInput.className = oldInput.className; 
    newInput.style.cssText = oldInput.style.cssText; 
    // TODO: copy any other relevant attributes 

    oldInput.parentNode.replaceChild(newInput, oldInput); 
    
    var oldInput = document.getElementById('ph_name');
    var newInput = document.createElement("input"); 
    newInput.type = "file"; 
    newInput.id = oldInput.id; 
    newInput.name = oldInput.name; 
    newInput.className = oldInput.className; 
    newInput.style.cssText = oldInput.style.cssText; 
    // TODO: copy any other relevant attributes 

    oldInput.parentNode.replaceChild(newInput, oldInput); 
}
/*$(document).ready(function() {
	$("#username").keyup(function (e) {

				$(this).val($(this).val().replace(/\s/g, ''));
//removes spaces from username

		var username = $(this).val();
        console.log(username);
		if(username.length < 4){$("#user-result").html('');return;}

		if(username.length >= 4){
			$("#user-result").html('<img src="images/ajax-loader.gif" />');
			$.post('check_username.php', {'username':username}, function(data) {
			  $("#user-result").html(data);
			});
		}
	})
});*/
function check()
{
	if(window.location.href.split('=')[1] == '403')
		document.getElementById('login-result').innerHTML = "User name and Passwords don't match"
}

$(function() {
    $('#btnSignIn').click(function() {
 
        $.ajax({
            url: '/signIn',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                console.log(response);
                var response = JSON.parse(response);
                if(response['status'] == "200")
                {
                    
                    window.location = "/login";
                    
                }
                else
                    document.getElementById('messages').innerHTML = response['status'];
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});




    
    
/*window.onload = function () {
    if (! localStorage.justOnce) {
        localStorage.setItem("justOnce", "true");
        window.location.reload();
    }
}
*/
$(function() {
    $('#btnSignUp').click(function() {
       var photo = false;
        var signup = false;
        var e = '';
        var opts = {
  lines: 13,
  length: 3,
  width: 2,
  radius:4,
  left: '20px',
opacity:0.25,
speed:1.0,
trail:60
};
var target = document.getElementById('btnSignUp');
target.style.position = 'relative';
target.style.padding = '10px 20px 10px 34px';

var spinner = new Spinner(opts).spin(target);
document.getElementById('btnSignUp').disabled = true;

        $.ajax({
            url: '/SignUp',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                
                if(document.getElementById('ph').value){
            var form = $('#photoform')[0]; // You need to use standart javascript object here
        var form_data = new FormData(form);
        form_data.append('mis',document.getElementById('username').value);
        $.ajax({
            type: 'POST',
            url: '/photo',
            data: form_data,
            contentType: false,
            processData: false,
            success: function(response) {
                document.getElementById('signupbox').style.display = 'none';
            document.getElementById('msg').style.display = 'block';
            document.getElementById('alert-1').style.display = 'block';
            document.getElementById('alert-2').style.display = 'none';
                console.log(response);
            },
            
            error: function(error) {
                document.getElementById('signupbox').style.display = 'none';
            document.getElementById('msg').style.display = 'block';
            document.getElementById('alert-2').style.display = 'block';
            document.getElementById('alert-1').style.display = 'none';
                
            }
        });
        
        }
            else{
            document.getElementById('signupbox').style.display = 'none';
            document.getElementById('msg').style.display = 'block';
            document.getElementById('alert-1').style.display = 'block';
            document.getElementById('alert-2').style.display = 'none';
            }
            console.log(response);
            },
            error: function(error) {
            document.getElementById('signupbox').style.display = 'none';
            document.getElementById('msg').style.display = 'block';
            document.getElementById('alert-2').style.display = 'block';
            document.getElementById('alert-1').style.display = 'none';
            console.log(error);
            }
        });
        
        

        /*if (!validate())
            return false;*/
      /* $.ajax({
            url: '/SignUp',
            data: $('form').serialize(),
            type: 'POST',
            success: function(response) {
                console.log(response);
                      
            },
           
           
            error: function(error) {
                console.log(error);
            }
        });
        
        
        /*var form_data = new FormData($('#photoform')[0]);
        form_data.append('mis',document.getElementById('username').value);
        $.ajax({
            type: 'POST',
            url: '/photo',
            data: form_data,
            contentType: false,
            processData: false,
            success: function(response) {
                 document.getElementById('signupbox').style.display = 'none';
            document.getElementById('msg').style.display = 'block';
        
        
            
            document.getElementById('alert-1').style.display = 'block';
            document.getElementById('alert-2').style.display = 'none';
            },
            error: function(error) {
            }
        });*/
        
        
        
        
        
        
        
    });
});

$(function() {
    $('#mis').keyup(function() {
       
        var mis = document.getElementById('username').value;
        $.ajax({
            url: '/checkusername',
            data: "mis="+mis,
            type: 'POST',
            success: function(response) {
                console.log(response);
                var response = JSON.parse(response);
                if(response['status'] == 'available' && mis.length == 9 && /^\d+$/.test(mis))
                    {
                        document.getElementById('avail').style = ''; 
                        document.getElementById('na').style.display = 'none'; 

                        c_mis = true;
                        document.getElementById('mis').className = "input-group has-success";
                        validate();
                    }
                else{
                        document.getElementById('na').style = '';
                        document.getElementById('avail').style.display = 'none'; 

                        c_mis = false;
                        document.getElementById('mis').className = "input-group has-error";
                        validate();

                    
                }
            },
            error: function(error) {
                console.log(error);
            }
        });
        
        
    });
});


        
    
    

$(document).on('click', '#close-preview', function(){ 
    $('.image-preview').popover('hide');
    // Hover befor close the preview
    $('.image-preview').hover(
        function () {
           $('.image-preview').popover('show');
        }, 
         function () {
           $('.image-preview').popover('hide');
        }
    );    
});

$(function() {
    // Create the close button
    var closebtn = $('<button/>', {
        type:"button",
        text: 'x',
        id: 'close-preview',
        style: 'font-size: initial;',
    });
    closebtn.attr("class","close pull-right");
    // Set the popover default content
    $('.image-preview').popover({
        trigger:'manual',
        html:true,
        title: "<strong>Preview</strong>"+$(closebtn)[0].outerHTML,
        content: "There's no image",
        placement:'bottom'
    });
    // Clear event
    $('.image-preview-clear').click(function(){
        $('.image-preview').attr("data-content","").popover('hide');
        $('.image-preview-filename').val("");
        $('.image-preview-clear').hide();
        $('.image-preview-input input:file').val("");
        $(".image-preview-input-title").text("Browse"); 
    }); 
    // Create the preview image
    $(".image-preview-input input:file").change(function (){     
        var img = $('<img/>', {
            id: 'dynamic',
            width:250,
            height:200
        });      
        var file = this.files[0];
        var reader = new FileReader();
        // Set preview image into the popover data-content
        reader.onload = function (e) {
            $(".image-preview-input-title").text("Change");
            $(".image-preview-clear").show();
            $(".image-preview-filename").val(file.name);            
            img.attr('src', e.target.result);
            $(".image-preview").attr("data-content",$(img)[0].outerHTML).popover("show");
        }        
        reader.readAsDataURL(file);
    });  
});