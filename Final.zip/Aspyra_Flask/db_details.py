__author__ = 'pshubham'
db_name = 'aspyra'
db_user = 'root'
db_pass = 'shubham123'
