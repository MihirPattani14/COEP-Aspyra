var opts = {
  basePath: '',
  theme: {
    base: 'js/markdown/epiceditor.css',
    preview: 'js/markdown/bartik.css',
    editor: 'js/markdown/epic-light.css'
  }
}

var editor = new EpicEditor(opts).load();